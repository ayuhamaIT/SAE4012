<script setup>
// import HelloWorld from './components/HelloWorld.vue'
// import TheWelcome from './components/TheWelcome.vue'
import Header from './components/Header.vue'
import Footer from './components/Footer.vue'
// import Index from './components/Index.vue'
</script>

<template>
 <div>
   <Header />
   <router-view />
    <Footer />
 </div>
</template>
 



