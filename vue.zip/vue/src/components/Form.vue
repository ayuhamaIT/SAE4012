<template>
       <main>
        <head>
            <title>Connexion</title>
        </head>
        <div class="form-container">
            <h2 id="form-title">Connectez-vous à votre profil</h2>
            <form id="auth-form">
                <div class="mb-3">
                    <label for="username" class="form-label">Pseudo</label>
                    <input type="text" class="form-control" id="username" required>
                </div>
                <div class="mb-3" id="email-group" style="display: none;">
                    <label for="email" class="form-label">Adresse mail</label>
                    <input type="email" class="form-control" id="email">
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label">Mot de passe</label>
                    <input type="password" class="form-control" id="password" required>
                </div>
                <button type="submit" class="btn btn-success w-100" id="submit-btn">Valider</button>
            </form>
            <p class="mt-3">
                <a href="#" id="toggle-form">Je n’ai pas encore de compte</a>
            </p>
        </div>
    </main>

</template>

 <style scoped>
       main {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 80vh;
        }
        .form-container {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 500px;
            text-align: center;
        }
        h2 {
            color: #2c56a8;
            font-weight: bold;
            margin-bottom: 20px;
        }
        label {
            font-weight: bold;
            color: #333;
        }
        .form-control {
            border: 2px solid #6a0dad;
            border-radius: 5px;
        }
        .btn-success {
            background-color: #28a745;
            border: none;
            padding: 10px;
            font-size: 18px;
            border-radius: 5px;
        }
        .btn-success:hover {
            background-color: #218838;
        }
        a {
            color: #6a0dad;
            text-decoration: none;
            font-weight: bold;
        }
        a:hover {
            text-decoration: underline;
        }
        footer {
            background: #373642;
            color: white;
            padding: 15px;
            text-align: center;
            font-size: 14px;
            position: absolute;
            bottom: 0;
            width: 100%;
        }

 </style>

 <script>
    document.addEventListener("DOMContentLoaded", function () {
    const formTitle = document.getElementById("form-title");
    const emailGroup = document.getElementById("email-group");
    const toggleForm = document.getElementById("toggle-form");
    const submitBtn = document.getElementById("submit-btn");
    let isSignup = false;

    toggleForm.addEventListener("click", function (e) {
        e.preventDefault();
        isSignup = !isSignup;

        if (isSignup) {
            formTitle.textContent = "Créez un compte";
            emailGroup.style.display = "block";
            submitBtn.textContent = "S'inscrire";
            toggleForm.textContent = "J'ai déjà un compte";
        } else {
            formTitle.textContent = "Connectez-vous à votre profil";
            emailGroup.style.display = "none";
            submitBtn.textContent = "Valider";
            toggleForm.textContent = "Je n’ai pas encore de compte";
        }
    });

    document.getElementById("auth-form").addEventListener("submit", function (e) {
        e.preventDefault();
        const username = document.getElementById("username").value;
        const password = document.getElementById("password").value;
        const email = document.getElementById("email").value;

        if (isSignup) {
            console.log("Inscription:", { username, email, password });
            alert("Inscription réussie !");
        } else {
            console.log("Connexion:", { username, password });
            alert("Connexion réussie !");
        }
    });
});

 </script>