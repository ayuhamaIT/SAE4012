
<template>
    <main>
        <head>
            <title>Boutique</title>
        </head>
        <section class="filters text-center text-white py-4" style="background: #373642;">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-md-3 mb-2">
                        <select class="form-select text-white" id="select">
                            <option>Type d'ordinateur</option>
                            <option>Ordinateur Portable</option>
                            <option>PC fixe</option>
                        </select>
                    </div>
                    <div class="col-md-3 mb-2">
                        <select class="form-select text-white" id="select">
                            <option>Système d'exploitation</option>
                            <option>Windows</option>
                            <option>Mac</option>
                            <option>Linux</option>
                        </select>
                    </div>
                    <div class="col-md-3 mb-2">
                        <select class="form-select text-white" id="select">
                            <option>Type de produit</option>
                        </select>
                    </div>
                    <section class="filters text-center text-white py-4" style="background: #373642; cursor: pointer;">
                        <div class="mt-3">
                            <span>Prix min : <span id="min-price">50</span>€</span>
                            <input type="range" id="price-range" class="mx-2" min="50" max="1500" step="50" oninput="filterProducts()">
                            <span>Prix max : <span id="max-price">1500</span>€</span>
                        </div>
                    </section>
                </div>
            </div>
        </section>
        <section class="container my-5">
            <div class="row" id="product-list"></div>
        </section>
    </main>
</template>

 <style scoped>

  #active {
    color: #4B0082;
  }

  #select {
    background-color: #3366CC;
    cursor: pointer;
  }

 </style>

 <script>
        const products = [
          { ref: 'XYZ001', name: 'Produit 1', price: 150 },
          { ref: 'XYZ002', name: 'Produit 2', price: 300 },
          { ref: 'XYZ003', name: 'Produit 3', price: 450 },
          { ref: 'XYZ004', name: 'Produit 4', price: 600 },
          { ref: 'XYZ005', name: 'Produit 5', price: 750 },
          { ref: 'XYZ006', name: 'Produit 6', price: 900 }
        ];

        function displayProducts(filterPrice = 1500) {
          const productList = document.getElementById('product-list');
          productList.innerHTML = '';
          products.filter(p => p.price <= filterPrice).forEach(p => {
            productList.innerHTML += `
              <div class="col-md-4 mb-4">
                <div class="product-box">
                  <div class="product-img"></div>
                  <p> <a class="nav-link" href="produit.html">${p.name}</a><br>Référence: ${p.ref}<br>Prix: ${p.price}€</p>
                  <button class="add-to-cart" onclick="addToCart('${p.ref}', '${p.name}', ${p.price})">Ajouter au panier</button>
                </div>
              </div>`;
          });
        }

        function filterProducts() {
          let maxPrice = document.getElementById('price-range').value;
          document.getElementById('max-price').innerText = maxPrice;
          displayProducts(maxPrice);
        }

        function addToCart(ref, name, price) {
          let cart = JSON.parse(localStorage.getItem('cart')) || [];
          let existingProduct = cart.find(p => p.ref === ref);
          if (existingProduct) {
            existingProduct.quantity += 1;
          } else {
            cart.push({ ref, name, price, quantity: 1 });
          }
          localStorage.setItem('cart', JSON.stringify(cart));
          alert('Produit ajouté au panier!');
        }

        document.addEventListener("DOMContentLoaded", () => displayProducts());
</script>