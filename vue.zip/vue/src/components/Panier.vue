<template>
    <main>
        <head>
            <title>Panier</title>
        </head>
    <section class="container my-5">
        <h2 class="text-center">Votre panier</h2>
        <div class="container">
        <div class="row">
            <div id="cart-items" class="col-12 col-lg-8"></div>
            
            <div class="summary col-12 col-lg-3">
            <p>Somme des articles: <span id="subtotal">0€</span></p>
            <p>Frais d’expédition: <span id="shipping">15.50€</span></p>
            <p>Taxes (TVA): <span id="taxes">0€</span></p>
            <hr>
            <p><strong>Total TTC: <span id="total">0€</span></strong></p>
            <button class="pay-button">Payer</button>
            </div>
        </div>
        </div>
    </section>

    </main>
</template>

 <style scoped>
     .cart-item {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 15px;
    border-bottom: 1px solid #ddd;
  }
  .cart-item img {
    width: 80px;
    height: 80px;
    background: lightgray;
  }
  .quantity-control {
    display: flex;
    align-items: center;
  }
  .quantity-control button {
    background-color: #4CAF50;
    color: white;
    border: none;
    padding: 5px 10px;
    cursor: pointer;
  }

@media screen and (max-width:992px){
  .summary {
    border: 2px solid #4B0082;
    padding: 15px;
    height: fit-content;
    margin: 3em;
    width: 80%;
  }
}

@media screen and (min-width:993px){
  .summary{
    border: 2px solid #4B0082;
    padding: 15px;
    height: fit-content;
    margin: 3em;
    position: fixed;
    top: 35vh;
    right: 4vw;
  }
}

  .pay-button {
    background-color: #4DDB78;
    color: white;
    padding: 10px;
    width: 100%;
    border: none;
    cursor: pointer;
  }

  .pay-button:hover {
    background-color: #3aad5d
  }


 </style>

  <script>
    function loadCart() {
      let cart = JSON.parse(localStorage.getItem('cart')) || [];
      let cartItems = document.getElementById('cart-items');
      cartItems.innerHTML = '';
      let subtotal = 0;
      
      cart.forEach((item, index) => {
        subtotal += item.price * item.quantity;
        cartItems.innerHTML += `
          <div class="cart-item">
            <img src="placeholder.png" alt="${item.name}">
            <div>
              <p>${item.name}</p>
              <p>Référence: ${item.ref}</p>
              <p>Prix: ${item.price}€</p>
            </div>
            <div class="quantity-control">
              <button onclick="updateQuantity(${index}, -1)">-</button>
              <span class="mx-2">${item.quantity}</span>
              <button onclick="updateQuantity(${index}, 1)">+</button>
            </div>
            <button class="btn btn-danger" onclick="removeFromCart(${index})">Retirer</button>
          </div>
        `;
      });
      
      let tax = (subtotal * 0.05).toFixed(2); // Exemple TVA 5%
      let total = (subtotal + 15.50 + parseFloat(tax)).toFixed(2);
      document.getElementById('subtotal').innerText = subtotal.toFixed(2) + '€';
      document.getElementById('taxes').innerText = tax + '€';
      document.getElementById('total').innerText = total + '€';
    }
    
    function updateQuantity(index, change) {
      let cart = JSON.parse(localStorage.getItem('cart')) || [];
      cart[index].quantity += change;
      if (cart[index].quantity <= 0) {
        cart.splice(index, 1);
      }
      localStorage.setItem('cart', JSON.stringify(cart));
      loadCart();
    }
    
    function removeFromCart(index) {
      let cart = JSON.parse(localStorage.getItem('cart')) || [];
      cart.splice(index, 1);
      localStorage.setItem('cart', JSON.stringify(cart));
      loadCart();
    }
    
    document.addEventListener("DOMContentLoaded", loadCart);
  </script>
