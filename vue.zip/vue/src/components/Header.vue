<template>
  <nav class="navbar navbar-expand-lg navbar-light bg-white py-3">
    <div class="container">
      <a class="navbar-brand" href="/"><img src="../assets/LOGO.png" alt="LenscreenLogo"></a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarContent">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarContent">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item"><a class="nav-link" href="boutique">Boutique</a></li>
          <li class="nav-item"><a class="nav-link" href="panier">Panier</a></li>
          <li class="nav-item"><a class="nav-link" href="connexion">Compte</a></li>
        </ul>
      </div>
    </div>
  </nav>

</template>

<style scoped>
 .navbar-brand img {
    height: 40px;
  }
  
  .navbar-nav .nav-link {
    color: #333;
    font-weight: bold;
  }

</style>