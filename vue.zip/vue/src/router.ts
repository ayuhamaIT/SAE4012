import { createRouter, createWebHistory } from 'vue-router'

import NotFound from './components/NotFound.vue'
import Index from './components/Index.vue'
import Form from './components/Form.vue'
import Boutique from './components/Boutique.vue'
import Panier from './components/Panier.vue'

const routes = [
  {
    path: '/',
    name: 'Index',
    component: Index
  },
  {
    path: '/boutique',
    name: 'boutique',
    component: Boutique
  },
  {
    path: '/connexion',
    name: 'Form',
    component: Form
  },
  {
    path: '/panier',
    name: 'Panier',
    component: Panier
  },
  {
    path: '/:pathMatch(.*)*',
    name: 'NotFound',
    component: NotFound
  }
]

export default createRouter({
  history: createWebHistory(),
  routes
});