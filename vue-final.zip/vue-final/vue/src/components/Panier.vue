<template>
  <main>
    <head>
      <title>Panier</title>
    </head>
    <section class="container my-5">
      <h2 class="text-center">Votre panier</h2>
      <div class="container">
        <div class="row">
          <div class="col-12 col-lg-8">
            <div v-if="cart.length > 0">
              <div v-for="(item, index) in cart" :key="item.ref" class="cart-item">
                <img src="" :alt="item.name">
                <div>
                  <p>{{ item.name }}</p>
                  <p>Référence: {{ item.ref }}</p>
                  <p>Prix: {{ item.price }}€</p>
                </div>
                <div class="quantity-control">
                  <button @click="updateQuantity(index, -1)">-</button>
                  <span class="mx-2">{{ item.quantity }}</span>
                  <button @click="updateQuantity(index, 1)">+</button>
                </div>
                <button class="btn btn-danger" @click="removeFromCart(index)">Retirer</button>
              </div>
            </div>
            <p v-else>Aucun article dans le panier.</p>
          </div>
          <div class="summary col-12 col-lg-3">
            <p>Somme des articles: <span>{{ subtotal.toFixed(2) }}€</span></p>
            <p>Frais d’expédition: <span>15.50€</span></p>
            <p>Taxes (TVA): <span>{{ taxes.toFixed(2) }}€</span></p>
            <hr>
            <p><strong>Total TTC: <span>{{ total.toFixed(2) }}€</span></strong></p>
            <button class="pay-button">Payer</button>
          </div>
        </div>
      </div>
    </section>
  </main>
</template>

<script>
import { ref, computed, onMounted } from 'vue';

export default {
  setup() {
    const cart = ref([]);
    
    const loadCart = () => {
      cart.value = JSON.parse(localStorage.getItem('cart')) || [];
    };
    
    const updateQuantity = (index, change) => {
      cart.value[index].quantity += change;
      if (cart.value[index].quantity <= 0) {
        cart.value.splice(index, 1);
      }
      localStorage.setItem('cart', JSON.stringify(cart.value));
    };
    
    const removeFromCart = (index) => {
      cart.value.splice(index, 1);
      localStorage.setItem('cart', JSON.stringify(cart.value));
    };
    
    const subtotal = computed(() => {
      return cart.value.reduce((sum, item) => sum + item.price * item.quantity, 0);
    });
    
    const taxes = computed(() => {
      return subtotal.value * 0.05; // Exemple TVA 5%
    });
    
    const total = computed(() => {
      return subtotal.value + 15.50 + taxes.value;
    });
    
    onMounted(loadCart);
    
    return {
      cart,
      subtotal,
      taxes,
      total,
      updateQuantity,
      removeFromCart
    };
  }
};
</script>

<style scoped>
.cart-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 15px;
  border-bottom: 1px solid #ddd;
}
.cart-item img {
  width: 80px;
  height: 80px;
  background: lightgray;
}
.quantity-control {
  display: flex;
  align-items: center;
}
.quantity-control button {
  background-color: #4CAF50;
  color: white;
  border: none;
  padding: 5px 10px;
  cursor: pointer;
}
@media screen and (max-width:992px) {
  .summary {
    border: 2px solid #4B0082;
    padding: 15px;
    height: fit-content;
    margin: 3em;
    width: 80%;
  }
}
@media screen and (min-width:993px) {
  .summary {
    border: 2px solid #4B0082;
    padding: 15px;
    height: fit-content;
    margin: 3em;
    position: fixed;
    top: 35vh;
    right: 4vw;
  }
}
.pay-button {
  background-color: #4DDB78;
  color: white;
  padding: 10px;
  width: 100%;
  border: none;
  cursor: pointer;
}
.pay-button:hover {
  background-color: #3aad5d;
}
</style>
