<template>
  <main>
    <head>
      <title>Boutique</title>
    </head>
    <section class="filters text-center text-white py-4" style="background: #373642;">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-md-3 mb-2">
            <select v-model="selectedType" class="form-select text-white" @change="filterProducts">
              <option value="">Type d'ordinateur</option>
              <option value="portable">Ordinateur Portable</option>
              <option value="fixe">PC fixe</option>
            </select>
          </div>
          <div class="col-md-3 mb-2">
            <select v-model="selectedOS" class="form-select text-white" @change="filterProducts">
              <option value="">Système d'exploitation</option>
              <option value="windows">Windows</option>
              <option value="mac">Mac</option>
              <option value="linux">Linux</option>
            </select>
          </div>
        </div>
        <div class="mt-3">
          <span>Prix min : 50€</span>
          <input type="range" v-model="maxPrice" class="mx-2" max="1500" step="50" @input="filterProducts">
          <span>Prix max : {{ maxPrice }}€</span>
        </div>
      </div>
    </section>

    <section class="container my-5">
      <div class="row">
        <div v-for="product in filteredProducts" :key="product.ref" class="col-md-4 mb-4">
          <div class="product-box">
            <div class="placeholder mb-3" style="height: 150px; background-color: #f0f0f0;"></div>
            <p>
              <a class="nav-link" :href="'/' + product.ref">{{ product.name }}</a>
              Référence: {{ product.ref }}<br>
              Prix: {{ product.price }}€<br>
              Type: {{ product.type }}<br>
              OS: {{ product.os }}
            </p>
            <button class="add-to-cart" @click="handleAddToCart(product)">Ajouter au panier</button>
          </div>
        </div>
      </div>
    </section>
  </main>
</template>

<script>
import { ref, computed } from 'vue';

export default {
  setup() {
    const selectedType = ref('');
    const selectedOS = ref('');
    const maxPrice = ref(1500);
    
    const products = ref([
      { ref: 'XYZ001', name: 'Produit 1', price: 150, type: 'portable', os: 'windows' },
      { ref: 'XYZ002', name: 'Produit 2', price: 300, type: 'fixe', os: 'mac' },
      { ref: 'XYZ003', name: 'Produit 3', price: 450, type: 'portable', os: 'linux' },
      { ref: 'XYZ004', name: 'Produit 4', price: 600, type: 'fixe', os: 'windows' },
      { ref: 'XYZ005', name: 'Produit 5', price: 750, type: 'portable', os: 'mac' },
      { ref: 'XYZ006', name: 'Produit 6', price: 900, type: 'fixe', os: 'linux' },
      { ref: 'XYZ007', name: 'Produit 7', price: 1000, type: 'portable', os: 'windows' },
      { ref: 'XYZ008', name: 'Produit 8', price: 1150, type: 'fixe', os: 'mac' },
      { ref: 'XYZ009', name: 'Produit 9', price: 1500, type: 'portable', os: 'linux' },
    ]);

    const filteredProducts = computed(() => {
      return products.value.filter(p => {
        const priceFilter = p.price <= maxPrice.value;
        const typeFilter = selectedType.value ? p.type === selectedType.value : true;
        const osFilter = selectedOS.value ? p.os === selectedOS.value : true;

        return priceFilter && typeFilter && osFilter;
      });
    });

    const filterProducts = () => {
      console.log("Filtrage en cours...");
    };

    const handleAddToCart = (product) => {
      let cart = JSON.parse(localStorage.getItem('cart')) || [];
      let existingProduct = cart.find(p => p.ref === product.ref);
      if (existingProduct) {
        existingProduct.quantity += 1;
      } else {
        cart.push({ ...product, quantity: 1 });
      }
      localStorage.setItem('cart', JSON.stringify(cart));
      alert('Produit ajouté au panier!');
    };

    return {
      selectedType,
      selectedOS,
      maxPrice,
      filteredProducts,
      filterProducts,
      handleAddToCart
    };
  }
};
</script>

<style scoped>
a:hover {
  color: #3366CC;
}

option {
  background-color: #3366CC;
  cursor: pointer;
}

.form-select {
  background-color: #3366CC;
}

.product-box { 
  text-align: center; 
  padding: 15px;
}

.product-img { 
  width: 100%; 
  height: 200px; 
  background: lightgray; 
}

.product-img { 
  transform: scale(1.1); 
  transition: transform 0.3s ease; 
}

.add-to-cart { 
  background-color: #4DDB78; 
  color: white; 
  border: none; 
  padding: 10px; 
  cursor: pointer; 
  margin-top: 10px; 
  border-radius: 15px;
  margin-bottom: 15px; 
}

.add-to-cart:hover { 
  background-color: #3aad5d;
}

.placeholder {
    background-color: #f0f0f0;
    border: 1px solid #ddd;
    text-align: center;
    display: flex;
    justify-content: center;
    align-items: center;
    font-size: 16px;
    color: #888;
  }
</style>
