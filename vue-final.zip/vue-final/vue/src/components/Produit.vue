<template>
    <main class="container mt-5" v-if="product">
      <div class="row">
        <div class="col-md-6">
          <div class="placeholder mb-3" style="height: 200px; background-color: #f0f0f0;"></div>
        </div>
        <div class="col-md-6">
          <h2 class="fw-bold">{{ product.name }}</h2>
          <p class="fw-bold fs-4">stock:{{ product.stock }}</p>
          <p v-if="product.stock > 0" id="textViolet">En stock</p>
          <p v-else id="textRed">Rupture de stock</p>
          <p class="fw-bold fs-4">{{ product.price }} €</p>
  
          <div class="d-flex align-items-center mb-3">
            <button class="btn btn-outline-secondary" @click="decreaseQuantity">-</button>
            <input type="text" v-model="quantity" class="form-control text-center mx-2" style="width: 60px;">
            <button class="btn btn-outline-secondary" @click="increaseQuantity">+</button>
          </div>
  
          <button class="btn btn-success w-100" @click="addToCart">Ajouter au panier</button>
        </div>
        <p class="fw-bold fs-4">Description:</p>
        <p>"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."</p>
      </div>
    </main>
  </template>
  
  <script>
  import { ref, onMounted } from 'vue';
  
  export default {
    props: ['id'],
    setup(props) {
      const products = ref([
        { ref: 'XYZ001', name: 'Produit 1', price: 150, stock: 7 },
        { ref: 'XYZ002', name: 'Produit 2', price: 300, stock: 20 },
        { ref: 'XYZ003', name: 'Produit 3', price: 450, stock: 9 },
        { ref: 'XYZ004', name: 'Produit 4', price: 600, stock: 8 },
        { ref: 'XYZ005', name: 'Produit 5', price: 750, stock: 4 },
        { ref: 'XYZ006', name: 'Produit 6', price: 900, stock: 15 },
        { ref: 'XYZ007', name: 'Produit 7', price: 1000, stock: 10 },
        { ref: 'XYZ008', name: 'Produit 8', price: 1150, stock: 5 },
        { ref: 'XYZ009', name: 'Produit 9', price: 1500, stock: 12 },
      ]);
  
      const product = ref(null);
      const quantity = ref(1);
  
      onMounted(() => {
        if (props.id) {
          product.value = products.value.find(p => p.ref === props.id);
        }
      });
  
      // Augmenter la quantité
      const increaseQuantity = () => {
        if (quantity.value < product.value.stock) quantity.value++;
      };
  
      // Diminuer la quantité
      const decreaseQuantity = () => {
        if (quantity.value > 1) quantity.value--;
      };
  
      // Ajouter au panier
      const addToCart = () => {
        if (!product.value) return;
  
        let cart = JSON.parse(localStorage.getItem('cart')) || [];
        let existingProduct = cart.find(p => p.ref === product.value.ref);
  
        if (existingProduct) {
          existingProduct.quantity += quantity.value;
        } else {
          cart.push({ ...product.value, quantity: quantity.value });
        }
  
        localStorage.setItem('cart', JSON.stringify(cart));
        alert(`${quantity.value} article(s) ajouté(s) au panier !`);
      };
  
      return { product, quantity, increaseQuantity, decreaseQuantity, addToCart };
    }
  };
  </script>
  
  <style scoped>
  #textViolet {
    color: purple;
  }
  
  #textRed {
    color: red;
  }
  
  .btn-outline-secondary {
    width: 40px;
  }
  
  .placeholder {
    background-color: #f0f0f0;
    border: 1px solid #ddd;
    text-align: center;
    display: flex;
    justify-content: center;
    align-items: center;
    font-size: 16px;
    color: #888;
  }
  </style>
  