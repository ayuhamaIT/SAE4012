<template>
<main>
  <head>
     <title>Accueil</title>
  </head>
    <section class="hero text-center text-white py-5" style="background: linear-gradient(135deg, #2b1f47, #1a0e30);">
        <div class="container">
        <h2 id="titreClair">Participez à notre jeu concours !!</h2>
        <button class="btn btn-success mt-3"><a class="link" href="https://bbgamestv.github.io/Game_SAE4012/">Jouer</a></button>
        </div>
    </section>
    
    <!-- Contenu principal -->
    <main class="container my-5 text-center">
        <h3>Lenscreen, la solution à long terme pour les yeux fatigués</h3>
        <p>Une technologie qui permet à l'écran de s'adapter à la vue de l'utilisateur afin de l'aider au quotidien ou même prévenir des risques éventuels car il vaut mieux prévenir que guérir!</p>
        <div class="bg-light" style="width: 100%; height: 300px;"></div>
    </main>
    
    <!-- Section Footer -->
    <section class="text-center text-white py-5" style="background: linear-gradient(180deg, #2b1f47, #373642);">
        <div class="container">
        <h2 id="titreClair">Pourquoi choisir lenscreen?</h2>
        <p class="pbas">Des problèmes de vue? Un confort visuel limité devant un écran où même une peur des conséquences à long terme? Lenscreen et sa technologie testée sur des vrais patients montrent des résultats exceptionnels sur l'amélioration du confot visuel mais aussi sur la baisse conséquente de la fatigue occulaire!</p>
        <button class="btn btn-success"><a class="nav-link" href="boutique">Découvrir nos produits</a></button>
        </div>
    </section>
  </main>
</template>
<style scoped>
 .hero {
    padding: 100px 0;
  }
  .hero h2 {
    font-size: 2rem;
  }
  
  /* Bouton principal */
  .btn-success {
    background-color: #4DDB78;
    border: none;
    padding: 10px 20px;
    font-size: 1.2rem;
    border-radius: 5px;
  }
  .btn-success:hover {
    background-color: #3aad5d;
  }
  
  a {
    text-decoration: none;
    color : white ;
  }
  /* Contenu principal */
  main h3 {
    font-size: 1.5rem;
    font-weight: bold;
  }

  .pbas {
    color: white;
  }
  
  main p {
    font-size: 1rem;
    color: #373642;
  }

  #textViolet{
    color:#4B0082;
  }

  #textBleuMedecin{
    color : #3366CC;
  }

  


 </style>