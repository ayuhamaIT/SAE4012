import { createRouter, createWebHistory } from 'vue-router'

import NotFound from './components/NotFound.vue'
import Index from './components/Index.vue'
import Form from './components/Form.vue'
import Boutique from './components/Boutique.vue'
import Panier from './components/Panier.vue'
import Produit from './components/Produit.vue' 

const routes = [
  {
    path: '/',
    name: 'Index',
    component: Index
  },
  {
    path: '/boutique',
    name: 'boutique',
    component: Boutique
  },
  {
    path: '/connexion',
    name: 'Form',
    component: Form
  },
  {
    path: '/panier',
    name: 'Panier',
    component: Panier
  },

  {
    path: '/:id',   
    name: 'Produit',
    component: Produit,     
    props: true            
  },
  {
    path: '/:pathMatch(.*)*',
    name: 'NotFound',
    component: NotFound
  }
]

export default createRouter({
  history: createWebHistory(),
  routes
});
