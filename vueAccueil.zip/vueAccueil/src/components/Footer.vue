<template>
    <footer class=" text-white py-3 text-center">
    <div class="container">
      <p>@Lenscreen. Tous droits réservés</p>
      <small>Produits | FAQ | Qu'est-ce que Lenscreen?</small>
    </div>
  </footer>
</template>

 <style scoped>
 footer {
    font-size: 0.9rem;
    background-color: #373642;
    position: absolute;
    bottom: 0;
    width: 100%;
  }

 </style>
