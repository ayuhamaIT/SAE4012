<template>
<div>
    <section class="hero text-center text-white py-5" style="background: linear-gradient(135deg, #2b1f47, #1a0e30);">
        <div class="container">
        <h2 id="titreClair">Participez à notre jeu concours !!</h2>
        <button class="btn btn-success mt-3">Jouer</button>
        </div>
    </section>
    
    <!-- Contenu principal -->
    <main class="container my-5 text-center">
        <h3>Le neurolab a pour but de mettre en page des</h3>
        <p>Accédez facilement aux données provenant de la recherche sur le dépistage du spectre autistique chez une population âgée de 2 à 13 ans.</p>
        <div class="bg-light" style="width: 100%; height: 200px;"></div>
    </main>
    
    <!-- Section Footer -->
    <section class="text-center text-white py-5" style="background: linear-gradient(135deg, #2b1f47, #1a0e30);">
        <div class="container">
        <h2 id="titreClair">Le neurolab a pour but de</h2>
        <p>Accédez facilement aux données provenant de la recherche sur le dépistage du spectre autistique chez une population âgée de 2 à 13 ans.</p>
        <button class="btn btn-success"><a class="nav-link" href="boutique.html">Découvrir nos produits</a></button>
        </div>
    </section>
  </div>
</template>
<style scoped>
 .hero {
    padding: 100px 0;
  }
  .hero h2 {
    font-size: 2rem;
    font-weight: bold;
  }
  
  /* Bouton principal */
  .btn-success {
    background-color: #4DDB78;
    border: none;
    padding: 10px 20px;
    font-size: 1.2rem;
    border-radius: 5px;
  }
  .btn-success:hover {
    background-color: #3aad5d;
  }
  
  /* Contenu principal */
  main h3 {
    font-size: 1.5rem;
    font-weight: bold;
  }
  
  main p {
    font-size: 1rem;
    color: #373642;
  }

  #textViolet{
    color:#4B0082;
  }

  #textBleuMedecin{
    color : #3366CC;
  }

  


 </style>